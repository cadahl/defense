<?xml version="1.0" encoding="UTF-8"?>
<tileset name="spawns" firstgid="257" tilewidth="32" tileheight="32">
 <image source="spawns.png" trans="ff00ff"/>
 <tile id="0">
  <properties>
   <property name="spawn" value="enemy"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="blocktype" value="nobuild"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="spawn" value="base"/>
  </properties>
 </tile>
</tileset>
